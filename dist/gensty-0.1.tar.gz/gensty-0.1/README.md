# genSty
Latex package generator for ttf/otf fonts. Supports SMuFL.
# Incomplete project

